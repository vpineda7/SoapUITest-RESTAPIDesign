import com.eviware.soapui.impl.wsdl.WsdlProject;
import com.eviware.soapui.impl.wsdl.WsdlTestSuite;
import com.eviware.soapui.impl.wsdl.testcase.WsdlTestCase;
import com.eviware.soapui.impl.wsdl.testcase.WsdlTestCaseRunner;
import com.eviware.soapui.model.support.PropertiesMap;
import com.eviware.soapui.model.testsuite.TestRunner;
import com.eviware.soapui.support.SoapUIException;
import org.apache.xmlbeans.XmlException;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.io.IOException;

public class testRunner {
	public static void main(String[] args) throws XmlException, IOException, SoapUIException {
	}
	@Test
	public void runMultipleTestSuite() throws XmlException, IOException, SoapUIException {
		WsdlProject project = new WsdlProject("/Users/yangwang/Documents/Projects/SoapUIProject/Automation-soapui-project.xml");
		for(int i=0; i<project.getTestSuiteCount(); i++){
			WsdlTestSuite testSuite =
					project.getTestSuiteAt(i);
			for (int j = 0; j < testSuite.getTestCaseCount(); j++) {
				WsdlTestCase testCase =
						testSuite.getTestCaseAt(j);
				WsdlTestCaseRunner testRunner =	testCase.run(new PropertiesMap(), false);
				System.out.println(testRunner.getStatus());
				Assert.assertEquals(TestRunner.Status.FINISHED,testRunner.getStatus());
			}
		}
	}
	@Test
	public void runTestSuite() throws XmlException, IOException, SoapUIException {
		WsdlProject project = new WsdlProject("/Users/yangwang/Documents/Projects/SoapUIProject/Automation-soapui-project.xml");
		WsdlTestSuite testSuite =
				project.getTestSuiteByName("Testing1");
		for (int i = 0; i < testSuite.getTestCaseCount(); i++) {
			WsdlTestCase testCase =	testSuite.getTestCaseAt(i);
			WsdlTestCaseRunner testRunner =	testCase.run(new PropertiesMap(), false);
			Assert.assertEquals(TestRunner.Status.FINISHED,testRunner.getStatus());
		}
	}
	@Test
	public void runTestCase() throws XmlException, IOException, SoapUIException {
		WsdlProject project = new WsdlProject("/Users/yangwang/Documents/Projects/SoapUIProject/Automation-soapui-project.xml");
		WsdlTestSuite testSuite =
				project.getTestSuiteByName("Testing1");
		WsdlTestCase testCase =
				testSuite.getTestCaseByName("getEmployee");
		WsdlTestCaseRunner testCaseRunner =
				testCase.run(new PropertiesMap(), false);
		Assert.assertEquals(TestRunner.Status.FINISHED,
				testCaseRunner.getStatus());
	}
}
